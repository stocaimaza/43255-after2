import { BrowserRouter, Routes, Route } from "react-router-dom"
import NavBar from "./componentes/NavBar/NavBar"
import Home from "./componentes/Home/Home"
import Autos from "./componentes/Autos/Autos"
import Error404 from "./componentes/404Error/Error404"

const App = () => {
  return (
    <>
      <BrowserRouter>
        <NavBar />
        <Routes>
          <Route path="/" element={<Home/>}  />
          <Route path="/autos/:producto" element={<Autos/>} />
          <Route path="*" element={<Error404/>} />
        </Routes>
      </BrowserRouter>

    </>
  )
}

export default App