import { useParams } from "react-router-dom"
//useParams me permite tomar los parámetros de la URL y trabajar con estos datos. 

const Autos = () => {
    const {producto} = useParams();

  return (
    <div>
        <h2>Esta es la Sección donde vemos los autos</h2>
        <strong> Buscamos :  {producto} </strong>
    </div>
  )
}

export default Autos