import React from 'react'

const Home = () => {
  return (
    <div>
        <h2>Home con todos mis productos</h2>
        <p>Acá puedo renderizar todo mi inventario</p>
    </div>
  )
}

export default Home