import { Link, NavLink } from "react-router-dom"
import './NavBar.css'

const NavBar = () => {
  return (
    <header>
        <Link to={"/"}>
            <h1>Automotores Marolio</h1>
        </Link>

        <nav>
            <ul>
                <li>
                    <NavLink className="navLink" to={"/autos"}> Sección Autos </NavLink>
                </li>

                <li>
                    <NavLink className="navLink" to={"/camionetas"}> Sección Camionetas </NavLink>
                </li>
            </ul>
        </nav>


    </header>
  )
}

export default NavBar