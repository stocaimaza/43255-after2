import React from 'react'

const Error404 = () => {
  return (
    <div>
        <h2>Sitio en Construcción</h2>
        <h2>Error 404</h2>
        <h3>Gracias, vuelva prontus</h3>
    </div>
  )
}

export default Error404